<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Sistem Kas RT (SIRTES)</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 300px; }
        .login-card h2 { text-align: center; margin-bottom: 20px; color: #333; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-size: 14px; color: #666; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn-login { width: 100%; padding: 10px; background-color: #007bff; border: none; color: white; border-radius: 4px; font-weight: bold; cursor: pointer; }
        .btn-login:hover { background-color: #0056b3; }
        .error { color: red; font-size: 13px; text-align: center; margin-bottom: 10px; }
        .register-link { text-align: center; margin-top: 15px; font-size: 13px; color: #666; }
        .register-link a { color: #007bff; text-decoration: none; font-weight: bold; }
        .register-link a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="login-card">
    <h2>Login SIRTES</h2>
    
    <?php 
    if(isset($_GET['pesan']) && $_GET['pesan'] == "gagal"){
        echo "<div class='error'>Username atau Password salah!</div>";
    }
    if(isset($_GET['pesan']) && $_GET['pesan'] == "daftar_berhasil"){
        echo "<div style='color: green; font-size: 13px; text-align: center; margin-bottom: 10px;'>Pendaftaran berhasil! Silakan login.</div>";
    }
    ?>

    <form action="cek_login.php" method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required autocomplete="off">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn-login">Masuk</button>
    </form>

    <div class="register-link">
        Belum punya akun? <a href="register.php">Daftar di sini</a>
    </div>
</div>

</body>
</html>