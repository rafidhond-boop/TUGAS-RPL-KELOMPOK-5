<?php
session_start();
include '../koneksi.php';

// Cek hak akses warga
if(!isset($_SESSION['role']) || $_SESSION['role'] != "warga"){
    header("location: ../index.php?pesan=gagal");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Iuran Saya - Warga Kas RT</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7f6; color: #333; display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar Warga - Konsisten dengan Dashboard */
        .sidebar { width: 260px; min-width: 260px; background-color: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px; background: #0f172a; text-align: center; }
        .sidebar-header h2 { font-size: 1.2rem; color: #f8fafc; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex-grow: 1; overflow-y: auto; }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li.active a { 
            background-color: #334155; 
            color: #ffffff; 
            border-left: 4px solid #3b82f6; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; font-size: 1rem; flex-shrink: 0; }
        
        .sidebar-footer { padding: 20px; text-align: center; background: #0f172a; }
        .btn-logout { display: block; padding: 10px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; font-size: 0.9rem; }
        .btn-logout:hover { background-color: #dc2626; }

        /* Main Content */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .header { background: white; padding: 20px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; color: #1e293b; }
        .user-profile { font-size: 0.95rem; color: #555; }
        .user-profile span { font-weight: 600; color: #3b82f6; }

        .content-body { padding: 30px; }
        
        .table-container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .table-container h3 { margin-bottom: 20px; color: #1e293b; font-size: 1.1rem; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        th { background-color: #f8fafc; color: #1e293b; font-weight: 600; }
        .badge { padding: 5px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; background-color: #dcfce7; color: #166534; }
    </style>
</head>
<body>

    <!-- SIDEBAR WARGA -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>🏠 Warga Kas RT</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
            <li class="active"><a href="riwayat.php"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Iuran Saya</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="header">
            <h1>Riwayat Iuran Saya</h1>
            <div class="user-profile">
                Halo, <span><?php echo htmlspecialchars(isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : 'Warga'); ?></span>
            </div>
        </div>

        <div class="content-body">
            <div class="table-container">
                <h3><i class="fa-solid fa-receipt"></i> Daftar Pembayaran Iuran Kas RT</h3>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Keterangan Transaksi</th>
                            <th>Jenis</th>
                            <th>Jumlah Nominal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $cek_tabel = mysqli_query($koneksi, "SHOW TABLES LIKE 'transaksi_kas'");
                        if(mysqli_num_rows($cek_tabel) > 0) {
                            // Menampilkan khusus transaksi kas masuk (iuran)
                            $sql = mysqli_query($koneksi, "SELECT * FROM transaksi_kas WHERE jenis = 'Masuk' ORDER BY tanggal DESC, id DESC");
                            if($sql && mysqli_num_rows($sql) > 0){
                                while($data = mysqli_fetch_assoc($sql)){
                                    $format_jumlah = number_format($data['jumlah'], 0, ',', '.');
                                    echo "<tr>
                                        <td>{$no}</td>
                                        <td>" . date('d F Y', strtotime($data['tanggal'])) . "</td>
                                        <td>{$data['keterangan']}</td>
                                        <td><span class='badge'>Masuk</span></td>
                                        <td style='color: #166534; font-weight: 500;'>Rp {$format_jumlah}</td>
                                    </tr>";
                                    $no++;
                                }
                            } else {
                                echo "<tr><td colspan='5' style='text-align: center; color: #64748b;'>Belum ada data iuran tercatat.</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' style='text-align: center; color: #64748b;'>Belum ada data transaksi.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>