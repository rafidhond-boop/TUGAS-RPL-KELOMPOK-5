<?php
session_start();
include '../koneksi.php';

// Cek hak akses admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin"){
    header("location: ../index.php?pesan=gagal");
    exit;
}

// Proses Tambah Transaksi
if(isset($_POST['tambah_transaksi'])){
    $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);
    $jenis = mysqli_real_escape_string($koneksi, $_POST['jenis']);
    $jumlah = mysqli_real_escape_string($koneksi, $_POST['jumlah']);
    $id_warga = !empty($_POST['id_warga']) ? $_POST['id_warga'] : NULL;

    if($id_warga) {
        $query = "INSERT INTO transaksi_kas (tanggal, keterangan, jenis, jumlah, id_warga) VALUES ('$tanggal', '$keterangan', '$jenis', '$jumlah', '$id_warga')";
    } else {
        $query = "INSERT INTO transaksi_kas (tanggal, keterangan, jenis, jumlah, id_warga) VALUES ('$tanggal', '$keterangan', '$jenis', '$jumlah', NULL)";
    }

    if(mysqli_query($koneksi, $query)){
        header("location: transaksi.php?pesan=sukses");
        exit;
    } else {
        $error = "Gagal menyimpan transaksi: " . mysqli_error($koneksi);
    }
}

// Proses Hapus Transaksi
if(isset($_GET['aksi']) && $_GET['aksi'] == 'hapus'){
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM transaksi_kas WHERE id = '$id'");
    header("location: transaksi.php?pesan=terhapus");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Transaksi Kas - Admin Kas RT</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7f6; color: #333; display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar Konsisten */
        .sidebar { width: 260px; min-width: 260px; background-color: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px; background: #0f172a; text-align: center; }
        .sidebar-header h2 { font-size: 1.2rem; color: #f8fafc; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex-grow: 1; overflow-y: auto; }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li.active a { 
            background-color: #334155; 
            color: #ffffff; 
            border-left: 4px solid #3b82f6; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; font-size: 1rem; flex-shrink: 0; }
        
        .sidebar-footer { padding: 20px; text-align: center; background: #0f172a; }
        .btn-logout { display: block; padding: 10px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; font-size: 0.9rem; }
        .btn-logout:hover { background-color: #dc2626; }

        /* Main Content */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .header { background: white; padding: 20px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; color: #1e293b; }
        .user-profile { font-size: 0.95rem; color: #555; }
        .user-profile span { font-weight: 600; color: #3b82f6; }

        .content-body { padding: 30px; }
        
        .form-container, .table-container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 30px; }
        .form-container h3, .table-container h3 { margin-bottom: 20px; color: #1e293b; font-size: 1.1rem; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-size: 0.9rem; color: #475569; font-weight: 500; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem; outline: none; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #3b82f6; }
        
        .btn-submit { background-color: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 500; transition: 0.3s; }
        .btn-submit:hover { background-color: #2563eb; }

        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        th { background-color: #f8fafc; color: #1e293b; font-weight: 600; }
        .badge { padding: 5px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; }
        .badge.masuk { background-color: #dcfce7; color: #166534; }
        .badge.keluar { background-color: #fee2e2; color: #991b1b; }
        .btn-delete { background-color: #fee2e2; color: #991b1b; padding: 6px 10px; border-radius: 4px; text-decoration: none; font-size: 0.8rem; font-weight: 500; transition: 0.3s; }
        .btn-delete:hover { background-color: #fecaca; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <h2>🏢 Admin Kas RT</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard Admin</a></li>
            <li><a href="warga.php"><i class="fa-solid fa-users"></i> Kelola Data Warga</a></li>
            <li class="active"><a href="transaksi.php"><i class="fa-solid fa-wallet"></i> Kelola Transaksi Kas</a></li>
            <li><a href="laporan.php"><i class="fa-solid fa-file-lines"></i> Laporan Keuangan</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Kelola Transaksi Kas RT</h1>
            <div class="user-profile">
                Halo, <span><?php echo htmlspecialchars(isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : 'Admin'); ?></span>
            </div>
        </div>

        <div class="content-body">
            <?php if(isset($error)) { echo "<div style='background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; margin-bottom: 20px;'>{$error}</div>"; } ?>

            <div class="form-container">
                <h3><i class="fa-solid fa-plus-circle"></i> Tambah Transaksi Baru</h3>
                <form action="" method="POST">
                    <div class="form-group">
                        <label>Tanggal Transaksi</label>
                        <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis Transaksi</label>
                        <select name="jenis" required>
                            <option value="Masuk">Kas Masuk (Iuran)</option>
                            <option value="Keluar">Kas Keluar (Pengeluaran)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Pilih Warga (Opsional, khusus Kas Masuk)</label>
                        <select name="id_warga">
                            <option value="">-- Bukan dari Warga / Umum --</option>
                            <?php
                            $q_warga = mysqli_query($koneksi, "SELECT * FROM data_warga ORDER BY nama_lengkap ASC");
                            while($w = mysqli_fetch_assoc($q_warga)){
                                echo "<option value='{$w['id']}'>{$w['nama_lengkap']} ({$w['alamat']})</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah (Rp)</label>
                        <input type="number" name="jumlah" placeholder="Contoh: 50000" required>
                    </div>
                    <div class="form-group">
                        <label>Keterangan / Keperluan</label>
                        <textarea name="keterangan" rows="3" placeholder="Contoh: Iuran Bulanan Warga Bulan Oktober" required></textarea>
                    </div>
                    <button type="submit" name="tambah_transaksi" class="btn-submit"><i class="fa-solid fa-save"></i> Simpan Transaksi</button>
                </form>
            </div>

            <div class="table-container">
                <h3><i class="fa-solid fa-list"></i> Riwayat Seluruh Transaksi Kas</h3>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $sql = mysqli_query($koneksi, "SELECT * FROM transaksi_kas ORDER BY tanggal DESC, id DESC");
                        if($sql && mysqli_num_rows($sql) > 0){
                            while($data = mysqli_fetch_assoc($sql)){
                                $format_jumlah = number_format($data['jumlah'], 0, ',', '.');
                                $badge_class = ($data['jenis'] == 'Masuk') ? 'masuk' : 'keluar';
                                $text_color = ($data['jenis'] == 'Masuk') ? '#166534' : '#991b1b';
                                $prefix_rp = ($data['jenis'] == 'Masuk') ? 'Rp ' : '- Rp ';
                                
                                echo "<tr>
                                    <td>{$no}</td>
                                    <td>" . date('d F Y', strtotime($data['tanggal'])) . "</td>
                                    <td>{$data['keterangan']}</td>
                                    <td><span class='badge {$badge_class}'>{$data['jenis']}</span></td>
                                    <td style='color: {$text_color}; font-weight: 500;'>{$prefix_rp}{$format_jumlah}</td>
                                    <td>
                                        <a href='transaksi.php?aksi=hapus&id={$data['id']}' class='btn-delete' onclick='return confirm(\"Yakin ingin menghapus transaksi ini?\")'><i class='fa-solid fa-trash'></i> Hapus</a>
                                    </td>
                                </tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr><td colspan='6' style='text-align: center; color: #64748b;'>Belum ada data transaksi kas.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>