<?php
session_start();
include '../koneksi.php';

// Cek hak akses admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin"){
    header("location: ../index.php?pesan=gagal");
    exit;
}

// Inisialisasi awal nilai
$total_masuk = 0;
$total_keluar = 0;
$total_saldo = 0;

// Cek apakah tabel transaksi_kas sudah ada sebelum melakukan query
$cek_tabel = mysqli_query($koneksi, "SHOW TABLES LIKE 'transaksi_kas'");
if(mysqli_num_rows($cek_tabel) > 0) {
    $query_masuk = mysqli_query($koneksi, "SELECT SUM(jumlah) as total_masuk FROM transaksi_kas WHERE jenis='Masuk'");
    if($query_masuk) {
        $data_masuk = mysqli_fetch_assoc($query_masuk);
        $total_masuk = $data_masuk['total_masuk'] ? $data_masuk['total_masuk'] : 0;
    }

    $query_keluar = mysqli_query($koneksi, "SELECT SUM(jumlah) as total_keluar FROM transaksi_kas WHERE jenis='Keluar'");
    if($query_keluar) {
        $data_keluar = mysqli_fetch_assoc($query_keluar);
        $total_keluar = $data_keluar['total_keluar'] ? $data_keluar['total_keluar'] : 0;
    }

    $total_saldo = $total_masuk - $total_keluar;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Sistem Informasi Kas RT</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7f6; color: #333; display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar Admin (Disamakan persis) */
        .sidebar { width: 260px; min-width: 260px; background-color: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px; background: #0f172a; text-align: center; }
        .sidebar-header h2 { font-size: 1.2rem; color: #f8fafc; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex-grow: 1; overflow-y: auto; }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li.active a { 
            background-color: #334155; 
            color: #ffffff; 
            border-left: 4px solid #3b82f6; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; font-size: 1rem; flex-shrink: 0; }
        
        .sidebar-footer { padding: 20px; text-align: center; background: #0f172a; }
        .btn-logout { display: block; padding: 10px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; font-size: 0.9rem; }
        .btn-logout:hover { background-color: #dc2626; }

        /* Main Content */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .header { background: white; padding: 20px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; color: #1e293b; }
        .user-profile { font-size: 0.95rem; color: #555; }
        .user-profile span { font-weight: 600; color: #3b82f6; }

        /* Content Body */
        .content-body { padding: 30px; }
        
        /* Cards Grid */
        .cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); display: flex; align-items: center; }
        .card-icon { font-size: 2rem; margin-right: 15px; padding: 12px; border-radius: 8px; }
        .card-icon.blue { background: #eff6ff; color: #3b82f6; }
        .card-icon.green { background: #f0fdf4; color: #22c55e; }
        .card-icon.red { background: #fef2f2; color: #ef4444; }
        .card-info h3 { font-size: 0.85rem; color: #64748b; margin-bottom: 5px; }
        .card-info p { font-size: 1.25rem; font-weight: 600; color: #1e293b; }

        /* Action Panel & Table */
        .action-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-add { background-color: #3b82f6; color: white; padding: 10px 15px; border-radius: 4px; text-decoration: none; font-size: 0.9rem; font-weight: 500; display: inline-flex; align-items: center; gap: 8px; }
        .btn-add:hover { background-color: #2563eb; }

        .table-container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .table-container h3 { margin-bottom: 20px; color: #1e293b; font-size: 1.1rem; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        th { background-color: #f8fafc; color: #1e293b; font-weight: 600; }
        .badge { padding: 5px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; }
        .badge.masuk { background-color: #dcfce7; color: #166534; }
        .badge.keluar { background-color: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>

    <!-- SIDEBAR ADMIN -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>⚙ Admin Kas RT</h2>
        </div>
        <ul class="sidebar-menu">
            <li class="active"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard Admin</a></li>
            <li><a href="warga.php"><i class="fa-solid fa-users"></i> Kelola Data Warga</a></li>
            <li><a href="transaksi.php"><i class="fa-solid fa-wallet"></i> Kelola Transaksi Kas</a></li>
            <li><a href="#"><i class="fa-solid fa-file-lines"></i> Laporan Keuangan</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="header">
            <h1>Panel Kontrol Admin</h1>
            <div class="user-profile">
                Administrator: <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
            </div>
        </div>

        <div class="content-body">
            <div class="cards-grid">
                <div class="card">
                    <div class="card-icon blue"><i class="fa-solid fa-wallet"></i></div>
                    <div class="card-info">
                        <h3>Total Saldo Kas</h3>
                        <p>Rp <?php echo number_format($total_saldo, 0, ',', '.'); ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon green"><i class="fa-solid fa-arrow-trend-up"></i></div>
                    <div class="card-info">
                        <h3>Total Pemasukan</h3>
                        <p>Rp <?php echo number_format($total_masuk, 0, ',', '.'); ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon red"><i class="fa-solid fa-arrow-trend-down"></i></div>
                    <div class="card-info">
                        <h3>Total Pengeluaran</h3>
                        <p>Rp <?php echo number_format($total_keluar, 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <div class="action-bar">
                    <h3><i class="fa-solid fa-table-list"></i> Ringkasan Transaksi Kas RT Terbaru</h3>
                    <a href="transaksi.php" class="btn-add"><i class="fa-solid fa-plus"></i> Kelola / Tambah Transaksi</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $cek_tabel_trx = mysqli_query($koneksi, "SHOW TABLES LIKE 'transaksi_kas'");
                        if(mysqli_num_rows($cek_tabel_trx) > 0) {
                            $sql = mysqli_query($koneksi, "SELECT * FROM transaksi_kas ORDER BY tanggal DESC, id DESC LIMIT 5");
                            if($sql && mysqli_num_rows($sql) > 0){
                                while($data = mysqli_fetch_assoc($sql)){
                                    $format_jumlah = number_format($data['jumlah'], 0, ',', '.');
                                    $badge_class = ($data['jenis'] == 'Masuk') ? 'masuk' : 'keluar';
                                    $text_color = ($data['jenis'] == 'Masuk') ? '#166534' : '#991b1b';
                                    $prefix_rp = ($data['jenis'] == 'Masuk') ? 'Rp ' : '- Rp ';
                                    
                                    echo "<tr>
                                        <td>{$no}</td>
                                        <td>" . date('d F Y', strtotime($data['tanggal'])) . "</td>
                                        <td>{$data['keterangan']}</td>
                                        <td><span class='badge {$badge_class}'>{$data['jenis']}</span></td>
                                        <td style='color: {$text_color}; font-weight: 500;'>{$prefix_rp}{$format_jumlah}</td>
                                    </tr>";
                                    $no++;
                                }
                            } else {
                                echo "<tr><td colspan='5' style='text-align: center; color: #64748b;'>Belum ada data transaksi.</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' style='text-align: center; color: #64748b;'>Tabel transaksi_kas belum dibuat.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>