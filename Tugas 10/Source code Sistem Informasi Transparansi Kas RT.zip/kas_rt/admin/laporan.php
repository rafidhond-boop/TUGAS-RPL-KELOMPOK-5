<?php
session_start();
include '../koneksi.php';

// Cek hak akses admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin"){
    header("location: ../index.php?pesan=gagal");
    exit;
}

// Default filter tanggal (awal bulan sampai hari ini)
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : date('Y-m-01');
$tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : date('Y-m-d');

// Hitung Rekapitulasi berdasarkan Filter
$q_masuk = mysqli_query($koneksi, "SELECT SUM(jumlah) as total FROM transaksi_kas WHERE jenis='Masuk' AND tanggal BETWEEN '$tgl_mulai' AND '$tgl_selesai'");
$d_masuk = mysqli_fetch_assoc($q_masuk);
$total_masuk = $d_masuk['total'] ? $d_masuk['total'] : 0;

$q_keluar = mysqli_query($koneksi, "SELECT SUM(jumlah) as total FROM transaksi_kas WHERE jenis='Keluar' AND tanggal BETWEEN '$tgl_mulai' AND '$tgl_selesai'");
$d_keluar = mysqli_fetch_assoc($q_keluar);
$total_keluar = $d_keluar['total'] ? $d_keluar['total'] : 0;

$total_saldo = $total_masuk - $total_keluar;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Keuangan - Admin Kas RT</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7f6; color: #333; display: flex; height: 100vh; overflow: hidden; }
        
        .sidebar { width: 260px; min-width: 260px; background-color: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px; background: #0f172a; text-align: center; }
        .sidebar-header h2 { font-size: 1.2rem; color: #f8fafc; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex-grow: 1; overflow-y: auto; }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li.active a { 
            background-color: #334155; 
            color: #ffffff; 
            border-left: 4px solid #3b82f6; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; font-size: 1rem; flex-shrink: 0; }
        
        .sidebar-footer { padding: 20px; text-align: center; background: #0f172a; }
        .btn-logout { display: block; padding: 10px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; font-size: 0.9rem; }
        .btn-logout:hover { background-color: #dc2626; }

        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .header { background: white; padding: 20px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; color: #1e293b; }
        .user-profile { font-size: 0.95rem; color: #555; }
        .user-profile span { font-weight: 600; color: #3b82f6; }

        .content-body { padding: 30px; }
        
        .filter-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .filter-form { display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap; }
        .form-group { flex: 1; min-width: 180px; }
        .form-group label { display: block; font-size: 0.85rem; color: #64748b; margin-bottom: 5px; font-weight: 500; }
        .form-group input { width: 100%; padding: 9px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem; }
        
        .btn-filter { background-color: #3b82f6; color: white; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 500; transition: 0.3s; }
        .btn-filter:hover { background-color: #2563eb; }
        .btn-print { background-color: #10b981; color: white; text-decoration: none; padding: 10px 18px; border-radius: 6px; font-size: 0.9rem; font-weight: 500; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; }
        .btn-print:hover { background-color: #059669; }

        .cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 25px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .card h4 { font-size: 0.85rem; color: #64748b; margin-bottom: 8px; font-weight: 500; }
        .card p { font-size: 1.3rem; font-weight: 600; }
        .card.masuk p { color: #166534; }
        .card.keluar p { color: #991b1b; }
        .card.saldo p { color: #1d4ed8; }

        .table-container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .table-container h3 { margin-bottom: 20px; color: #1e293b; font-size: 1.1rem; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        th { background-color: #f8fafc; color: #1e293b; font-weight: 600; }
        .badge { padding: 5px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; }
        .badge.masuk { background-color: #dcfce7; color: #166534; }
        .badge.keluar { background-color: #fee2e2; color: #991b1b; }

        @media print {
            .sidebar, .header, .filter-container, .btn-print { display: none !important; }
            body { background: white; overflow: visible; height: auto; }
            .main-content { overflow: visible; }
            .content-body { padding: 0; }
            .table-container, .card { box-shadow: none; border: 1px solid #ddd; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <h2>🏢 Admin Kas RT</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard Admin</a></li>
            <li><a href="warga.php"><i class="fa-solid fa-users"></i> Kelola Data Warga</a></li>
            <li><a href="transaksi.php"><i class="fa-solid fa-wallet"></i> Kelola Transaksi Kas</a></li>
            <li class="active"><a href="laporan.php"><i class="fa-solid fa-file-lines"></i> Laporan Keuangan</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Laporan Keuangan Kas RT</h1>
            <div class="user-profile">
                Halo, <span><?php echo htmlspecialchars(isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : 'Admin'); ?></span>
            </div>
        </div>

        <div class="content-body">
            <div class="filter-container">
                <form action="" method="GET" class="filter-form">
                    <div class="form-group">
                        <label>Dari Tanggal</label>
                        <input type="date" name="tgl_mulai" value="<?php echo $tgl_mulai; ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Sampai Tanggal</label>
                        <input type="date" name="tgl_selesai" value="<?php echo $tgl_selesai; ?>" required>
                    </div>
                    <button type="submit" class="btn-filter"><i class="fa-solid fa-filter"></i> Filter Periodik</button>
                    <button type="button" onclick="window.print()" class="btn-print"><i class="fa-solid fa-print"></i> Cetak Laporan</button>
                </form>
            </div>

            <div class="cards-grid">
                <div class="card masuk">
                    <h4>Total Pemasukan Periode Ini</h4>
                    <p>Rp <?php echo number_format($total_masuk, 0, ',', '.'); ?></p>
                </div>
                <div class="card keluar">
                    <h4>Total Pengeluaran Periode Ini</h4>
                    <p>Rp <?php echo number_format($total_keluar, 0, ',', '.'); ?></p>
                </div>
                <div class="card saldo">
                    <h4>Saldo Kas Periode Ini</h4>
                    <p>Rp <?php echo number_format($total_saldo, 0, ',', '.'); ?></p>
                </div>
            </div>

            <div class="table-container">
                <h3><i class="fa-solid fa-list-check"></i> Detail Transaksi (<?php echo date('d/m/Y', strtotime($tgl_mulai)); ?> - <?php echo date('d/m/Y', strtotime($tgl_selesai)); ?>)</h3>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Keterangan Transaksi</th>
                            <th>Jenis</th>
                            <th>Nominal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $sql = mysqli_query($koneksi, "SELECT * FROM transaksi_kas WHERE tanggal BETWEEN '$tgl_mulai' AND '$tgl_selesai' ORDER BY tanggal ASC, id ASC");
                        if($sql && mysqli_num_rows($sql) > 0){
                            while($data = mysqli_fetch_assoc($sql)){
                                $format_jumlah = number_format($data['jumlah'], 0, ',', '.');
                                $badge_class = ($data['jenis'] == 'Masuk') ? 'masuk' : 'keluar';
                                $text_color = ($data['jenis'] == 'Masuk') ? '#166534' : '#991b1b';
                                $prefix_rp = ($data['jenis'] == 'Masuk') ? 'Rp ' : '- Rp ';
                                
                                echo "<tr>
                                    <td>{$no}</td>
                                    <td>" . date('d F Y', strtotime($data['tanggal'])) . "</td>
                                    <td>{$data['keterangan']}</td>
                                    <td><span class='badge {$badge_class}'>{$data['jenis']}</span></td>
                                    <td style='color: {$text_color}; font-weight: 500;'>{$prefix_rp}{$format_jumlah}</td>
                                </tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr><td colspan='5' style='text-align: center; color: #64748b;'>Tidak ada transaksi pada periode ini.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>