<?php
session_start();
include '../koneksi.php';

// Cek hak akses admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin"){
    header("location: ../index.php?pesan=gagal");
    exit;
}

$pesan_error = "";

// Proses tambah data warga jika form disubmit
if(isset($_POST['tambah_warga'])){
    $nik = mysqli_real_escape_string($koneksi, $_POST['nik']);
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $telepon = mysqli_real_escape_string($koneksi, $_POST['no_telepon']);

    $query = "INSERT INTO data_warga (nik, nama_lengkap, alamat, no_telepon) VALUES ('$nik', '$nama', '$alamat', '$telepon')";
    
    if(mysqli_query($koneksi, $query)){
        header("location: warga.php?status=sukses");
        exit;
    } else {
        $pesan_error = "Gagal menyimpan ke database: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data Warga - Admin Kas RT</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f7f6; color: #333; display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar Admin */
        .sidebar { width: 260px; min-width: 260px; background-color: #1e293b; color: white; display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px; background: #0f172a; text-align: center; }
        .sidebar-header h2 { font-size: 1.2rem; color: #f8fafc; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex-grow: 1; overflow-y: auto; }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li.active a { 
            background-color: #334155; 
            color: #ffffff; 
            border-left: 4px solid #3b82f6; 
            font-size: 0.9rem; 
            font-weight: 400;
        }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; font-size: 1rem; flex-shrink: 0; }
        
        .sidebar-footer { padding: 20px; text-align: center; background: #0f172a; }
        .btn-logout { display: block; padding: 10px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; font-size: 0.9rem; }
        .btn-logout:hover { background-color: #dc2626; }

        /* Main Content */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .header { background: white; padding: 20px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; color: #1e293b; }
        .user-profile { font-size: 0.95rem; color: #555; }
        .user-profile span { font-weight: 600; color: #3b82f6; }

        /* Content Body */
        .content-body { padding: 30px; }
        
        .card-box { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .card-box h3 { margin-bottom: 20px; color: #1e293b; font-size: 1.1rem; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-size: 0.9rem; font-weight: 500; color: #334155; }
        .form-group input, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 0.9rem; }
        .btn-submit { background-color: #3b82f6; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 500; }
        .btn-submit:hover { background-color: #2563eb; }

        .alert-success { background: #dcfce7; color: #166534; padding: 10px 15px; border-radius: 4px; margin-bottom: 20px; font-size: 0.9rem; }
        .alert-error { background: #fee2e2; color: #991b1b; padding: 10px 15px; border-radius: 4px; margin-bottom: 20px; font-size: 0.9rem; }

        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        th { background-color: #f8fafc; color: #1e293b; font-weight: 600; }
        .btn-action { padding: 5px 10px; border-radius: 3px; font-size: 0.8rem; text-decoration: none; color: white; }
        .btn-delete { background-color: #ef4444; }
        .btn-delete:hover { background-color: #dc2626; }
    </style>
</head>
<body>

    <!-- SIDEBAR ADMIN -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>⚙ Admin Kas RT</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard Admin</a></li>
            <li class="active"><a href="warga.php"><i class="fa-solid fa-users"></i> Kelola Data Warga</a></li>
            <li><a href="transaksi.php"><i class="fa-solid fa-wallet"></i> Kelola Transaksi Kas</a></li>
            <li><a href="#"><i class="fa-solid fa-file-lines"></i> Laporan Keuangan</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="header">
            <h1>Kelola Data Warga</h1>
            <div class="user-profile">
                Administrator: <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
            </div>
        </div>

        <div class="content-body">
            <?php 
            if(isset($_GET['status']) && $_GET['status'] == 'sukses') { 
                echo "<div class='alert-success'>Data warga berhasil ditambahkan!</div>"; 
            }
            if($pesan_error != "") {
                echo "<div class='alert-error'>{$pesan_error}</div>";
            }
            ?>

            <!-- FORM TAMBAH WARGA -->
            <div class="card-box">
                <h3><i class="fa-solid fa-user-plus"></i> Tambah Data Warga Baru</h3>
                <form action="warga.php" method="POST">
                    <div class="form-group">
                        <label>NIK</label>
                        <input type="text" name="nik" required placeholder="Masukkan 16 digit NIK">
                    </div>
                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" required placeholder="Nama lengkap warga">
                    </div>
                    <div class="form-group">
                        <label>Alamat / Blok Rumah</label>
                        <textarea name="alamat" rows="2" required placeholder="Contoh: Blok A No. 12"></textarea>
                    </div>
                    <div class="form-group">
                        <label>No Telepon / WhatsApp</label>
                        <input type="text" name="no_telepon" required placeholder="08xxxxxxxxxx">
                    </div>
                    <button type="submit" name="tambah_warga" class="btn-submit"><i class="fa-solid fa-save"></i> Simpan Data Warga</button>
                </form>
            </div>

            <!-- TABEL DAFTAR WARGA -->
            <div class="card-box">
                <h3><i class="fa-solid fa-table"></i> Daftar Warga Terdaftar</h3>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama Lengkap</th>
                            <th>Alamat</th>
                            <th>No Telepon</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $sql = mysqli_query($koneksi, "SELECT * FROM data_warga ORDER BY id DESC");
                        if($sql && mysqli_num_rows($sql) > 0){
                            while($data = mysqli_fetch_assoc($sql)){
                                echo "<tr>
                                    <td>{$no}</td>
                                    <td>{$data['nik']}</td>
                                    <td>{$data['nama_lengkap']}</td>
                                    <td>{$data['alamat']}</td>
                                    <td>{$data['no_telepon']}</td>
                                    <td>
                                        <a href='hapus_warga.php?id={$data['id']}' class='btn-action btn-delete' onclick='return confirm(\"Yakin ingin menghapus data ini?\")'><i class='fa-solid fa-trash'></i> Hapus</a>
                                    </td>
                                </tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr><td colspan='6' style='text-align: center; color: #64748b;'>Belum ada data warga.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>