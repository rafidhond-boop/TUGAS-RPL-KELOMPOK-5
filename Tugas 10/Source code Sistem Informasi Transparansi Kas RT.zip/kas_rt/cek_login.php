<?php
session_start();
include 'koneksi.php';

$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);

$data = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($data);

if($cek > 0){
    $row = mysqli_fetch_assoc($data);
    
    $_SESSION['username'] = $row['username'];
    $_SESSION['nama_lengkap'] = $row['nama_lengkap'];
    // Menggunakan fungsi strtolower agar aman jika di database role-nya 'Admin' atau 'admin'
    $_SESSION['role'] = strtolower($row['role']);

    if($_SESSION['role'] == "admin"){
        header("location: admin/dashboard.php");
    }else if($_SESSION['role'] == "warga"){
        header("location: warga/dashboard.php");
    }
}else{
    header("location: index.php?pesan=gagal");
}
?>