<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Akun - Sistem Kas RT</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 350px; }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-size: 14px; color: #666; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { width: 100%; padding: 10px; background-color: #28a745; border: none; color: white; border-radius: 4px; font-weight: bold; cursor: pointer; }
        .btn:hover { background-color: #218838; }
        .link { text-align: center; margin-top: 15px; font-size: 13px; }
        .link a { color: #007bff; text-decoration: none; }
        .success { color: green; font-size: 13px; text-align: center; margin-bottom: 10px; }
        .error { color: red; font-size: 13px; text-align: center; margin-bottom: 10px; }
    </style>
</head>
<body>

<div class="card">
    <h2>Daftar Akun SIRTES</h2>

    <?php
    include 'koneksi.php';
    if(isset($_POST['daftar'])) {
        $username     = mysqli_real_escape_string($koneksi, $_POST['username']);
        $password     = mysqli_real_escape_string($koneksi, $_POST['password']); // Bisa dikasih md5() kalau mau dienkripsi
        $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
        $role         = mysqli_real_escape_string($koneksi, $_POST['role']);

        // Cek apakah username sudah ada
        $cek_user = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");
        if(mysqli_num_rows($cek_user) > 0){
            echo "<div class='error'>Username sudah digunakan! Pilih yang lain.</div>";
        } else {
            // Masukkan data ke database MySQL
            $query = "INSERT INTO users (username, password, nama_lengkap, role) VALUES ('$username', '$password', '$nama_lengkap', '$role')";
            if(mysqli_query($koneksi, $query)){
                echo "<div class='success'>Pendaftaran berhasil! <a href='index.php'>Silakan Login</a></div>";
            } else {
                echo "<div class='error'>Gagal mendaftar, coba lagi.</div>";
            }
        }
    }
    ?>

    <form action="" method="POST">
        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" required autocomplete="off">
        </div>
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required autocomplete="off">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>Daftar Sebagai</label>
            <select name="role">
                <option value="warga">Warga</option>
                <option value="admin">Admin / Bendahara</option>
            </select>
        </div>
        <button type="submit" name="daftar" class="btn">Daftar Sekarang</button>
    </form>

    <div class="link">
        Sudah punya akun? <a href="index.php">Login di sini</a>
    </div>
</div>

</body>
</html>